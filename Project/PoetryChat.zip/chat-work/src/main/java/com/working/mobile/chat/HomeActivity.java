package com.working.mobile.chat;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;

import androidx.annotation.Nullable;

public class HomeActivity extends Activity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FrameLayout frameLayout = new FrameLayout(this);
        Button button = new Button(this);
        button.setText("初始化");
        frameLayout.addView(button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (InitManager.isBinderAlive()) {
                    InitManager.init(HomeActivity.this);
                }
            }
        });
        setContentView(frameLayout);
    }
}
