package com.working.mobile.chat;

import android.app.Application;

import com.poetry.common.SettingConfig;
import com.virtual.util.log.VLogConfig;

public class App extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        VLogConfig.instance().defaultConfig(this, "ChatWork", SettingConfig.DEBUG);
    }
}
