package com.working.mobile.chat;

import android.content.Context;

import com.lvmosed.manager.ConfigManager;
import com.virtual.util.log.VLog;

import java.util.HashSet;
import java.util.Set;

public class InitManager {

    public static boolean isBinderAlive() {
        boolean isBinderAlive = ConfigManager.isBinderAlive();
        VLog.w("InitManager", "isBinderAlive=" + isBinderAlive);
        return isBinderAlive;
    }

    public static void init(Context context) {
        try {
            initModule(context);
            VLog.w("InitManager", "init reboot");
            ConfigManager.reboot(false);
        } catch (Throwable th) {
            VLog.e("InitManager", "init Throwable=" + th.getMessage());
        }
    }

    public static void initModule(Context context) {
        String pkg = context.getPackageName();
        VLog.w("InitManager", "initModule start " + pkg);
        try {
            ConfigManager.setModuleEnabled(pkg, true);
            Set<ConfigManager.ApplicationWithEquals> withEquals = new HashSet<>();
            withEquals.add(new ConfigManager.ApplicationWithEquals("android", 0));
            withEquals.add(new ConfigManager.ApplicationWithEquals("com.android.systemui", 0));

            withEquals.add(new ConfigManager.ApplicationWithEquals("com.tencent.mm", 0));
            withEquals.add(new ConfigManager.ApplicationWithEquals("com.tencent.mm", 999));

            ConfigManager.setModuleScope(pkg, withEquals);

            VLog.w("InitManager", "initModule end");
        } catch (Throwable th) {
            VLog.e("InitManager", "initModule Throwable=" + th.getMessage());
        }
    }
}
