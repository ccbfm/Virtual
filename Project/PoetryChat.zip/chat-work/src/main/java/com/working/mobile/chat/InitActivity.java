package com.working.mobile.chat;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;

import androidx.annotation.Nullable;

public class InitActivity extends Activity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(new View(this));
        if (InitManager.isBinderAlive()) {
            InitManager.init(this);
        } else {
            finish();
        }
    }
}
