package com.working.mobile.chat.startup;


import android.content.Context;
import android.util.Log;

import com.android.chat.client.ChatClientManager;
import com.poetry.hook.core.PLoadPackage;
import com.poetry.hook.core.PoetryHelper;
import com.poetry.hook.core.Poetry_MHook;
import com.poetry.server.PoetryServerManager;

public class Startup extends PLoadPackage {
    private static final String TAG = "Startup";
    private static final String ANDROID = "android";
    private static final String SYSTEM_UI = "com.android.systemui";
    private static final String CHAT_MM = "com.tencent.mm";

    @Override
    public void handleLoadPackage(PPackageParam pPackageParam) {
        final ClassLoader classLoader = pPackageParam.classLoader;
        String packageName = pPackageParam.packageName;
        final String processName = pPackageParam.processName;
        if (pPackageParam.appInfo != null) {
            packageName = pPackageParam.appInfo.packageName;
        }
        Log.e("Startup", "handleLoadPackage " + packageName + " " + processName);

        boolean isAndroid = (ANDROID.equals(packageName) && ANDROID.equals(processName));
        boolean isSystemUI = (SYSTEM_UI.equals(packageName) && SYSTEM_UI.equals(processName));
        boolean isChatMM = (CHAT_MM.equals(packageName) && CHAT_MM.equals(processName));
        if (isAndroid || isSystemUI || isChatMM) {
            try {
                Class<?> cla0 = PoetryHelper.findClass("android.app.ContextImpl", classLoader);
                //Class<?> cla1 = PoetryHelper.findClass("android.app.ActivityThread", classLoader);
                //Class<?> cla2 = PoetryHelper.findClass("android.app.LoadedApk", classLoader);
                PoetryHelper.hookAllMethods(cla0, "createAppContext", new Poetry_MHook() {
                    @Override
                    protected void afterHookedMethod(MHookParam param) throws Throwable {
                        try {
                            Context context = (Context) param.getResult();
                            String packageName = context.getPackageName();
                            //Log.w(TAG, "packageName " + packageName + " " + context);
                            if (SYSTEM_UI.equals(packageName)) {
                                PoetryServerManager.instance().start(context);
                            } else if (ANDROID.equals(packageName)) {

                            } else if (CHAT_MM.equals(packageName)) {
                                ChatClientManager.instance().start(context);
                            }
                        } catch (Throwable throwable) {
                            Log.e(TAG, "getApplicationContext 1 Throwable ", throwable);
                        }
                    }
                });
            } catch (Throwable throwable) {
                Log.e("Startup", "getApplicationContext Throwable ", throwable);
            }
        }
    }
}
