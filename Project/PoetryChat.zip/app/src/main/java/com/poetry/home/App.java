package com.poetry.home;

import android.app.Application;

import com.virtual.util.log.VLogConfig;

public class App extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        VLogConfig.instance().defaultConfig(this, "PoetryHome", true);
    }
}
