package com.poetry.home.view;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import com.poetry.home.HomeLoader;
import com.poetry.home.model.AppModel;
import com.poetry.home.model.ShiCiModel;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.LinkedList;
import java.util.List;

@SuppressLint("ViewConstructor")
public class DisplayView extends FrameLayout {
    private @DisplayType int mDisplayType = DisplayType.NONE;
    private final int mWidth, mHeight;

    public DisplayView(@NonNull Context context, int width, int height) {
        super(context);
        mWidth = width;
        mHeight = height;
    }

    public void setDisplayType(@DisplayType int displayType) {
        if (mDisplayType == displayType) {
            return;
        }
        mDisplayType = displayType;
        if (displayType == DisplayType.APP) {
            addAppView(getContext());
            HomeLoader.instance().loadSpecificApp(getContext(), new HomeLoader.LoadCallback<List<AppModel>>() {
                @Override
                public void result(boolean result, List<AppModel> data) {
                    if (result) {
                        if (mAppAdapter != null) {
                            mAppAdapter.setModels(data);
                        }
                    }
                }
            });
        }
    }

    private AppAdapter mAppAdapter;

    private void addAppView(Context context) {
        if (mAppAdapter != null) {
            return;
        }
        removeAllViews();
        RecyclerView appView = new RecyclerView(context);
        appView.setLayoutManager(new LinearLayoutManager(context, RecyclerView.VERTICAL, false));
        AppAdapter appAdapter = new AppAdapter(context, mWidth, (mHeight >> 2));
        appView.setAdapter(appAdapter);
        mAppAdapter = appAdapter;
    }

    private void addShiCiView(Context context){

        removeAllViews();
        ViewPager2 viewPager2 = new ViewPager2(context);
        ShiCiAdapter shiCiAdapter = new ShiCiAdapter(context, mWidth, mHeight);
        viewPager2.setAdapter(shiCiAdapter);
    }

    private static class AppAdapter extends RecyclerView.Adapter<AppHolder> {
        private final Context context;
        private final int itemW, itemH;
        private final List<AppModel> appModels = new LinkedList<>();

        public AppAdapter(Context context, int itemW, int itemH) {
            this.context = context;
            this.itemW = itemW;
            this.itemH = itemH;
        }

        @SuppressLint("NotifyDataSetChanged")
        public void setModels(List<AppModel> appModels) {
            this.appModels.clear();
            this.appModels.addAll(appModels);
            notifyDataSetChanged();
        }

        @NonNull
        @Override
        public AppHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new AppHolder(new FrameLayout(context), itemW, itemH);
        }

        @Override
        public void onBindViewHolder(@NonNull AppHolder holder, int position) {

        }

        @Override
        public int getItemCount() {
            return this.appModels.size();
        }
    }

    private static class AppHolder extends RecyclerView.ViewHolder {

        public AppHolder(@NonNull FrameLayout itemView, int itemW, int itemH) {
            super(itemView);
        }
    }

    private static class ShiCiAdapter extends RecyclerView.Adapter<ShiCiHolder> {
        private final Context context;
        private final int itemW, itemH;
        private final List<ShiCiModel> shiCiModels = new LinkedList<>();

        public ShiCiAdapter(Context context, int itemW, int itemH) {
            this.context = context;
            this.itemW = itemW;
            this.itemH = itemH;
        }

        @NonNull
        @Override
        public ShiCiHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return null;
        }

        @Override
        public void onBindViewHolder(@NonNull ShiCiHolder holder, int position) {

        }

        @Override
        public int getItemCount() {
            return this.shiCiModels.size();
        }
    }


    private static class ShiCiHolder extends RecyclerView.ViewHolder {

        public ShiCiHolder(@NonNull View itemView) {
            super(itemView);
        }
    }

    @Retention(RetentionPolicy.SOURCE)
    public @interface DisplayType {
        int NONE = 0;
        int APP = 1;
    }




}
