package com.poetry.home.model;

import android.content.Intent;
import android.graphics.drawable.Drawable;

public class AppModel {

    public CharSequence name;
    public Drawable icon;
    public long versionCode;
    public String versionName;
    public Intent intent;
}
