package com.poetry.home;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;

import com.poetry.home.model.MenuKey;
import com.poetry.home.model.MenuModel;
import com.poetry.home.view.DisplayView;
import com.poetry.home.view.MenuRecyclerView;
import com.virtual.generic.zxing.CaptureActivity;
import com.virtual.util.common.ToastUtils;
import com.virtual.util.log.VLog;

import java.util.Arrays;
import java.util.List;

public class HomeActivity extends Activity {
    private static final String TAG = "HomeActivity";
    private DisplayView mDisplayView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(initView(this));
    }

    private final View.OnClickListener mOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            final Object tag = v.getTag();
            VLog.d(TAG, "onClick tag " + tag);
            if (tag != null) {
                String tagStr = tag.toString();
                if (MenuKey.SCAN.equals(tagStr)) {
                    CaptureActivity.start(HomeActivity.this, CODE_CAPTURE_REQUEST, CODE_CAPTURE_PERMISSION_REQUEST);
                } else if (MenuKey.FUNCTION.equals(tagStr)) {
                    mDisplayView.setDisplayType(DisplayView.DisplayType.APP);
                }
            }
        }
    };

    private View initView(Context context) {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int height = dm.heightPixels;
        int width = dm.widthPixels;

        FrameLayout content = new FrameLayout(context);
        content.setBackgroundColor(0x8FD3D3D3);

        List<MenuModel> menuModels = HomeLoader.instance().getMenus(context, mOnClickListener);
        int menusSize = menuModels.size();
        int sHp = 0;
        int siHp = height / 9;
        int appHp = height;
        int topAppHp = 0;
        if (menusSize > 0) {
            int rows = Math.min((menusSize / 4) + (menusSize % 4 == 0 ? 0 : 1), 2);
            sHp = siHp * rows;
            int siWp = width >> 2;

            MenuRecyclerView menuRV = new MenuRecyclerView(this);
            menuRV.setAdapter(new MenuRecyclerView.MenuAdapter(this, menuModels, siWp, siHp));
            FrameLayout.LayoutParams sLp = new FrameLayout.LayoutParams(-1, sHp);
            content.addView(menuRV, sLp);
            appHp = height - sHp;
            topAppHp = sHp;
        }

        int seWp = width >> 4;
        int appWp = width - seWp - seWp;
        DisplayView displayRV = new DisplayView(context, appWp, appHp);
        mDisplayView = displayRV;
        FrameLayout.LayoutParams viewPager2Lp = new FrameLayout.LayoutParams(appWp, appHp);
        viewPager2Lp.topMargin = topAppHp;
        viewPager2Lp.leftMargin = seWp;
        viewPager2Lp.rightMargin = seWp;
        content.addView(displayRV, viewPager2Lp);
        return content;
    }

    private static final int CODE_CAPTURE_REQUEST = 0x11, CODE_CAPTURE_PERMISSION_REQUEST = 0x12;

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == CODE_CAPTURE_REQUEST) {
                String scan_result = data.getStringExtra("scan_result");
                VLog.d(TAG, "onActivityResult scan_result: " + scan_result);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        VLog.d(TAG, "onRequestPermissionsResult requestCode: " + requestCode
                + " " + Arrays.toString(permissions)
                + " " + Arrays.toString(grantResults));
        if (requestCode == CODE_CAPTURE_PERMISSION_REQUEST) {
            if (grantResults[0] == 0) {
                CaptureActivity.start(HomeActivity.this, CODE_CAPTURE_REQUEST, CODE_CAPTURE_PERMISSION_REQUEST);
            } else {
                boolean shouldShow = ActivityCompat.shouldShowRequestPermissionRationale(this, permissions[0]);
                VLog.d(TAG, "onRequestPermissionsResult shouldShow: " + shouldShow);
                if (!shouldShow) {
                    ToastUtils.makeTextShortShow(this, "请在设置中打开相机权限");
                }
            }
        }
    }
}
