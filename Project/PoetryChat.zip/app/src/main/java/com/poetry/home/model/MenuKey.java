package com.poetry.home.model;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.SOURCE)
public @interface MenuKey {
    String SCAN = "扫码";
    String FUNCTION = "功能";
    String SETTINGS = "设置";
    String FILE_EXPLORER = "文件管理";
    String SHI = "诗";
    String CI = "词";
    String QU = "曲";
    String FU = "赋";
}
