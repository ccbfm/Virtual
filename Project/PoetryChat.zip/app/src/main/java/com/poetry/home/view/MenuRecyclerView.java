package com.poetry.home.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.poetry.home.model.MenuModel;

import java.util.List;

public class MenuRecyclerView extends RecyclerView {

    public MenuRecyclerView(@NonNull Context context) {
        super(context);
        setLayoutManager(new GridLayoutManager(context, 4));
    }

    public static class MenuAdapter extends Adapter<MenuHolder> {
        private final Context context;
        private final int itemW, itemH;
        private final List<MenuModel> menus;

        public MenuAdapter(Context context, List<MenuModel> menus, int itemW, int itemH) {
            this.context = context;
            this.menus = menus;
            this.itemW = itemW;
            this.itemH = itemH;
        }

        @NonNull
        @Override
        public MenuHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new MenuHolder(new FrameLayout(context), itemW, itemH);
        }

        @Override
        public void onBindViewHolder(@NonNull MenuHolder holder, int position) {
            final MenuModel menuModel = this.menus.get(position);
            holder.icon.setImageDrawable(menuModel.icon);
            holder.name.setText(menuModel.name);
            if (menuModel.clickListener != null) {
                holder.itemView.setTag(menuModel.name);
                holder.itemView.setOnClickListener(menuModel.clickListener);
            } else if (menuModel.intent != null) {
                holder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        context.startActivity(menuModel.intent);
                    }
                });
            }
        }

        @Override
        public int getItemCount() {
            return menus.size();
        }
    }

    private static class MenuHolder extends ViewHolder {
        ImageView icon;
        TextView name;

        public MenuHolder(@NonNull FrameLayout itemView, int itemW, int itemH) {
            super(itemView);
            final Context context = itemView.getContext();

            int[] attrs = new int[]{android.R.attr.selectableItemBackground};
            TypedArray typedArray = context.obtainStyledAttributes(attrs);
            int backgroundResource = typedArray.getResourceId(0, 0);
            itemView.setBackgroundResource(backgroundResource);
            typedArray.recycle();

            int txtHp = itemH / 5;
            int iconHp = (int) (itemH * 3.f / 5.f);

            LinearLayout content = new LinearLayout(context);
            content.setGravity(Gravity.CENTER);
            content.setOrientation(LinearLayout.VERTICAL);

            this.icon = new ImageView(context);
            this.icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
            this.icon.setBackgroundColor(0x8FD3D3D3);
            content.addView(this.icon, new LinearLayout.LayoutParams(iconHp, iconHp));

            this.name = new TextView(context);
            this.name.setGravity(Gravity.CENTER);
            this.name.setTextColor(Color.BLACK);
            this.name.setSingleLine();
            this.name.setEms(6);
            this.name.setEllipsize(TextUtils.TruncateAt.MIDDLE);
            //this.name.setShadowLayer(2.0f, 2.0f, 2.0f, Color.BLACK);
            content.addView(this.name, new LinearLayout.LayoutParams(-1, txtHp));
            itemView.addView(content, new FrameLayout.LayoutParams(itemW, itemH));
        }

    }

}
