package com.poetry.home.model;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.view.View;

public class MenuModel {

    public Drawable icon;
    public String name;
    public View.OnClickListener clickListener;
    public Intent intent;

    public MenuModel(Drawable icon, String name, View.OnClickListener clickListener) {
        this.icon = icon;
        this.name = name;
        this.clickListener = clickListener;
    }

    public MenuModel(Drawable icon, String name, Intent intent) {
        this.icon = icon;
        this.name = name;
        this.intent = intent;
    }
}
