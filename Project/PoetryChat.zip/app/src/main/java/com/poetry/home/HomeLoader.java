package com.poetry.home;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;

import androidx.appcompat.content.res.AppCompatResources;

import com.poetry.home.model.AppModel;
import com.poetry.home.model.MenuKey;
import com.poetry.home.model.MenuModel;
import com.virtual.util.common.ToastUtils;
import com.virtual.util.log.VLog;

import java.util.LinkedList;
import java.util.List;

public class HomeLoader {

    private HomeLoader() {
    }

    private static final class Singleton {
        private static final HomeLoader INSTANCE = new HomeLoader();
    }

    public static HomeLoader instance() {
        return Singleton.INSTANCE;
    }

    private static final String TAG = "HomeLoader";
    private static final String POETRY_HOME = "poetry.intent.action.Home";

    public List<MenuModel> getMenus(Context context, View.OnClickListener clickListener) {
        List<MenuModel> menus = new LinkedList<>();
        menus.add(new MenuModel(AppCompatResources.getDrawable(context, R.drawable.qr_code_scanner_24), MenuKey.SCAN, clickListener));
        menus.add(new MenuModel(AppCompatResources.getDrawable(context, R.drawable.apps_24), MenuKey.FUNCTION, clickListener));

        Intent settings = new Intent(Settings.ACTION_SETTINGS);
        settings.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        menus.add(new MenuModel(AppCompatResources.getDrawable(context, R.drawable.settings_24), MenuKey.SETTINGS, settings));

        Intent fileExplorer = new Intent();
        fileExplorer.setComponent(new ComponentName("com.android.fileexplorer", "com.android.fileexplorer.MainActivity"));
        fileExplorer.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        menus.add(new MenuModel(AppCompatResources.getDrawable(context, R.drawable.folder_24), MenuKey.FILE_EXPLORER, fileExplorer));

        menus.add(new MenuModel(AppCompatResources.getDrawable(context, R.drawable.layers_24), MenuKey.SHI, clickListener));
        menus.add(new MenuModel(AppCompatResources.getDrawable(context, R.drawable.layers_24), MenuKey.CI, clickListener));
        menus.add(new MenuModel(AppCompatResources.getDrawable(context, R.drawable.layers_24), MenuKey.QU, clickListener));
        menus.add(new MenuModel(AppCompatResources.getDrawable(context, R.drawable.layers_24), MenuKey.FU, clickListener));
        return menus;
    }


    private Handler mMainHandler;

    private void checkMainHandler() {
        if (mMainHandler == null) {
            mMainHandler = new Handler(Looper.getMainLooper());
        }
    }

    private Thread mLoadSpecificApp;

    public void loadSpecificApp(Context context, LoadCallback<List<AppModel>> loadCallback) {
        checkMainHandler();
        if (mLoadSpecificApp != null) {
            ToastUtils.makeTextShortShow(context, "正在查找中");
            return;
        }
        Thread thread = new Thread() {
            @Override
            public void run() {
                List<AppModel> appModels = null;
                try {
                    PackageManager pm = context.getPackageManager();
                    Intent intent = new Intent(POETRY_HOME).addCategory(Intent.CATEGORY_LAUNCHER);
                    List<ResolveInfo> resolveInfoList;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        resolveInfoList =
                                pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0));
                    } else {
                        resolveInfoList = pm.queryIntentActivities(intent, 0);
                    }

                    if (resolveInfoList != null) {
                        appModels = new LinkedList<>();
                        for (ResolveInfo info : resolveInfoList) {
                            AppModel appModel = new AppModel();
                            appModel.name = info.loadLabel(pm);
                            appModel.icon = info.loadIcon(pm);
                            String packageName = info.activityInfo.packageName;

                            Intent intentT = new Intent();
                            intentT.setComponent(new ComponentName(packageName, info.activityInfo.name));
                            intentT.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            appModel.intent = intentT;

                            PackageInfo packageInfo = pm.getPackageInfo(packageName, 0);
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                                appModel.versionCode = packageInfo.getLongVersionCode();
                            } else {
                                appModel.versionCode = packageInfo.versionCode;
                            }
                            appModel.versionName = packageInfo.versionName;

                            appModels.add(appModel);
                        }
                    }
                } catch (Throwable throwable) {
                    VLog.e(TAG, "loadSpecificApp Throwable ", throwable);
                    appModels = null;
                }
                final boolean result = appModels != null;
                final List<AppModel> resultAppModels = appModels;
                mMainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        loadCallback.result(result, resultAppModels);
                    }
                });
                mLoadSpecificApp = null;
            }
        };
        mLoadSpecificApp = thread;
        thread.start();
    }

    public interface LoadCallback<T> {
        void result(boolean result, T data);
    }
}
