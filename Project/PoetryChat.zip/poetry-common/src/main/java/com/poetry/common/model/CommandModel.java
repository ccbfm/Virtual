package com.poetry.common.model;

import com.google.gson.annotations.SerializedName;
import com.poetry.common.GsonManager;
import com.poetry.common.SocketCommon;

import java.io.Serializable;

public class CommandModel implements Serializable {

    @SerializedName("command")
    @SocketCommon.Command
    public String command;

    @SerializedName("data_json")
    public String dataJson;


    public static <T> String toJson(String command, T data) {
        CommandModel commandModel = new CommandModel();
        commandModel.command = command;
        commandModel.dataJson = GsonManager.instance().toJson(data);
        return GsonManager.instance().toJson(commandModel);
    }
}
