package com.poetry.common;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.SOURCE)
public @interface SocketCommon {

    int[] SOCKET_PORTS = {41110, 42111, 43112, 44113, 45114};

    String NAME_SOCKET_SERVER = "poetry_socket_server";
    String NAME_SOCKET_SERVER_PORT = "poetry_socket_server_chat_port";
    String NAME_CHAT_CLIENT = "chat_client";


    @Retention(RetentionPolicy.SOURCE)
    @interface Command {

        String LOG = "log";
    }
}
