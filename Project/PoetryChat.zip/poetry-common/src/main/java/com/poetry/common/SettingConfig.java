package com.poetry.common;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.SOURCE)
public @interface SettingConfig {

    boolean DEBUG = true;//BuildConfig.DEBUG;
}
