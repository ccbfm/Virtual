package com.poetry.server;

import android.content.Context;
import android.provider.Settings;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.poetry.common.SettingConfig;
import com.poetry.common.SocketCommon;
import com.poetry.server.receiver.PackageReceiver;
import com.virtual.util.log.VLog;
import com.virtual.util.log.VLogConfig;
import com.virtual.util.network.VNetwork;
import com.virtual.util.network.VWebSocketManager;
import com.virtual.util.socket.net.VNetSocket;

import java.io.File;
import java.net.ServerSocket;

import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;

public class PoetryServerManager {
    private static final String TAG = "PoetryServerManager";

    private PoetryServerManager() {
    }

    private static final class Singleton {
        private static final PoetryServerManager INSTANCE = new PoetryServerManager();
    }

    public static PoetryServerManager instance() {
        return Singleton.INSTANCE;
    }


    private volatile boolean mInit = false;


    public synchronized void start(final Context context) {
        if (context == null) {
            Log.w(TAG, "start context is null.");
            return;
        }
        /*if (context.getExternalFilesDir(null) == null) {
            Log.d(TAG, "start externalFiles is null." + context.getFilesDir());
            return;
        }*/
        if (mInit) {
            //Log.d(TAG, "start init.");
            return;
        }
        mInit = true;
        VLogConfig.instance().defaultNotSaveConfig(context, "PoetryServer", SettingConfig.DEBUG);
        try {
            VNetwork.setCleartext();
            VNetwork.init();
            new Thread("poetry_server_init") {
                @Override
                public void run() {
                    try {
                        while (true) {
                            File file = context.getExternalFilesDir(null);
                            VLog.d(TAG, "ExternalFilesDir " + file);
                            if (file != null) {
                                break;
                            }
                            synchronized (this) {
                                wait(5000);
                            }
                        }
                        VLogConfig.instance().defaultConfig(context, "PoetryServer", SettingConfig.DEBUG);

                        PoetryDataManager.instance().init(context);
                        initWebSocketClient(context);
                        PackageReceiver.registerInstallReceiver(context, "com.working.mobile.chat", "com.working.mobile.chat.InitActivity");
                    } catch (Throwable throwable) {
                        VLog.e(TAG, "init Throwable ", throwable);
                    }
                }
            }.start();
            new Thread("poetry_server_start") {
                @Override
                public void run() {
                    try {
                        while (true) {
                            File file = context.getExternalFilesDir(null);
                            VLog.d(TAG, "ExternalFilesDir " + file);
                            if (file != null) {
                                break;
                            }
                            synchronized (this) {
                                wait(5000);
                            }
                        }
                        initNetSocketServer(context);
                    } catch (Throwable throwable) {
                        VLog.e(TAG, "init server_start Throwable ", throwable);
                    }
                }
            }.start();
        } catch (Throwable throwable) {
            VLog.e(TAG, "start Throwable ", throwable);
            mInit = false;
        }
    }


    private final Object mLockSocket = new Object();

    private void initNetSocketServer(Context context) {
        try {
            VLog.w(TAG, "initNetSocketServer start.");
            synchronized (mLockSocket) {
                final int[] success = {0, 0};
                while (true) {
                    VNetSocket.startServer(new PoetrySocketServer(0) {
                        @Override
                        protected void linkSuccess(ServerSocket serverSocket) {
                            super.linkSuccess(serverSocket);
                            int localPort = serverSocket.getLocalPort();
                            Settings.Global.putInt(context.getContentResolver(), SocketCommon.NAME_SOCKET_SERVER_PORT, localPort);
                            VLog.w(TAG, "initNetSocketServer start localPort " + localPort);
                            success[0] = 1;
                            success[1] = localPort;
                            synchronized (mLockSocket) {
                                mLockSocket.notify();
                            }
                        }

                        @Override
                        protected void doThrowable() {
                            super.doThrowable();
                            synchronized (mLockSocket) {
                                mLockSocket.notify();
                            }
                        }
                    });
                    mLockSocket.wait();
                    if (success[0] == 1) {
                        VLog.w(TAG, "initNetSocketServer success. port:" + success[1]);
                        break;
                    } else {
                        VLog.w(TAG, "initNetSocketServer fail.");
                    }
                }
            }
            VLog.w(TAG, "initNetSocketServer end.");
        } catch (Throwable throwable) {
            VLog.e(TAG, "start run NetSocket startServer ", throwable);
        }
    }


    private void initWebSocketClient(Context context) {
        try {
            VLog.w(TAG, "initWebSocketClient start.");
            VWebSocketManager.Builder builder = new VWebSocketManager.Builder(context, "ws://111.223.15.84:1261", new WebSocketListener() {
                @Override
                public void onClosed(@NonNull WebSocket webSocket, int code, @NonNull String reason) {
                    super.onClosed(webSocket, code, reason);
                    VLog.d(TAG, "WebSocketListener onClosed " + code + " " + reason);
                }

                @Override
                public void onFailure(@NonNull WebSocket webSocket, @NonNull Throwable t, @Nullable Response response) {
                    super.onFailure(webSocket, t, response);
                    VLog.d(TAG, "WebSocketListener onFailure " + response + " " + t.getMessage());
                }

                @Override
                public void onMessage(@NonNull WebSocket webSocket, @NonNull String text) {
                    super.onMessage(webSocket, text);
                    VLog.d(TAG, "WebSocketListener onMessage " + text);
                }

                @Override
                public void onOpen(@NonNull WebSocket webSocket, @NonNull Response response) {
                    super.onOpen(webSocket, response);
                    VLog.d(TAG, "WebSocketListener onOpen " + response);
                }
            });
            builder.setPingParam("{\"t\":0}", 30);
            builder.setRetryConnectTime(30);
            builder.setTimeout(30, 30, 30);
            builder.setWsStatusListener(new VWebSocketManager.WsStatusListener() {
                @Override
                public void change(int i, String s) {
                    VLog.w(TAG, "WsStatus change " + i + " " + s);
                }
            });
            VWebSocketManager.instance().startWebSocket("web_socket_back", builder);
            VLog.w(TAG, "initWebSocketClient end.");
        } catch (Throwable throwable) {
            VLog.e(TAG, "start run WebSocket startServer ", throwable);
        }
    }

}
