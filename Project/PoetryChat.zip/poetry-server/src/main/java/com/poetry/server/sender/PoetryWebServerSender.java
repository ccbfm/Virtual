package com.poetry.server.sender;

public final class PoetryWebServerSender {

    
}
