package com.poetry.server;

import android.os.Looper;

import androidx.annotation.NonNull;

import com.poetry.common.GsonManager;
import com.poetry.common.SocketCommon;
import com.poetry.common.model.CommandModel;
import com.poetry.common.model.command.LogModel;
import com.virtual.util.log.VLog;
import com.virtual.util.log.VLogLevel;
import com.virtual.util.socket.net.server.VServer;
import com.virtual.util.socket.net.server.VServerConnect;

import java.net.Socket;

public class PoetrySocketServer extends VServer {
    private final int port;

    public PoetrySocketServer(int port) {
        this.port = port;
    }

    @NonNull
    @Override
    public String address() {
        return SocketCommon.NAME_SOCKET_SERVER;
    }

    @Override
    public int port() {
        return this.port;
    }

    @Override
    protected VServerConnect createVServerConnect(int i, Socket socket, Looper looper, Looper looper1) {
        return new ServerConnect(i, socket, looper, looper1);
    }

    public static class ServerConnect extends VServerConnect {
        private String connectKey = "";

        public ServerConnect(int port, Socket socket, Looper acceptLooper, Looper sendLooper) {
            super(port, socket, acceptLooper, sendLooper);
        }

        @Override
        protected void recordConnect(String name, int userId) {
            super.recordConnect(name, userId);
            connectKey = name + "_" + userId;
        }

        @Override
        protected void handleResult(String s) {
            try {
                CommandModel commandModel = GsonManager.instance().fromJson(s, CommandModel.class);
                final String command = commandModel.command;
                final String dataJson = commandModel.dataJson;
                if (SocketCommon.Command.LOG.equals(command)) {
                    LogModel logModel = GsonManager.instance().fromJson(dataJson, LogModel.class);
                    final String tag = this.connectKey;
                    final int level = logModel.level;
                    final String msg = "[" + logModel.tag + "] " + logModel.msg;
                    if (level == VLogLevel.D) {
                        VLog.d(tag, msg);
                    } else if (level == VLogLevel.I) {
                        VLog.i(tag, msg);
                    } else if (level == VLogLevel.W) {
                        VLog.w(tag, msg);
                    } else if (level == VLogLevel.E) {
                        VLog.e(tag, msg);
                    }
                }
            } catch (Throwable throwable) {
                VLog.e("ServerConnect", "handleResult Throwable", throwable);
            }
        }
    }
}
