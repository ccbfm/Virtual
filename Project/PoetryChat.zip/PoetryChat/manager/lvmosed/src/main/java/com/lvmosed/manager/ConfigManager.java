/*
 * This file is part of LSPosed.
 *
 * LSPosed is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * LSPosed is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with LSPosed.  If not, see <https://www.gnu.org/licenses/>.
 *
 * Copyright (C) 2021 LSPosed Contributors
 */

package com.lvmosed.manager;

import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.ParcelFileDescriptor;
import android.os.RemoteException;
import android.util.Log;

import androidx.annotation.Nullable;

import com.lvmosed.manager.receivers.LVMManagerServiceHolder;

import org.lvmosed.lvmd.ILVMManagerService;
import org.lvmosed.lvmd.models.Application;
import org.lvmosed.lvmd.models.UserInfo;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Set;

public class ConfigManager {
    private static final String TAG = "ConfigManager";

    public static boolean isBinderAlive() {
        return LVMManagerServiceHolder.getService() != null;
    }

    public static int getXposedApiVersion() {
        try {
            return LVMManagerServiceHolder.getService().getXposedApiVersion();
        } catch (RemoteException e) {
            Log.e(TAG, Log.getStackTraceString(e));
            return -1;
        }
    }

    public static String getXposedVersionName() {
        try {
            return LVMManagerServiceHolder.getService().getXposedVersionName();
        } catch (RemoteException e) {
            Log.e(TAG, Log.getStackTraceString(e));
            return "";
        }
    }

    public static int getXposedVersionCode() {
        try {
            return LVMManagerServiceHolder.getService().getXposedVersionCode();
        } catch (RemoteException e) {
            Log.e(TAG, Log.getStackTraceString(e));
            return -1;
        }
    }

    public static List<PackageInfo> getInstalledPackagesFromAllUsers(int flags, boolean filterNoProcess) {
        List<PackageInfo> list = new ArrayList<>();
        try {
            list.addAll(LVMManagerServiceHolder.getService().getInstalledPackagesFromAllUsers(flags, filterNoProcess).getList());
        } catch (RemoteException e) {
            Log.e(TAG, Log.getStackTraceString(e));
        }
        return list;
    }

    public static String[] getEnabledModules() {
        try {
            return LVMManagerServiceHolder.getService().enabledModules();
        } catch (RemoteException e) {
            Log.e(TAG, Log.getStackTraceString(e));
            return new String[0];
        }
    }

    public static boolean setModuleEnabled(String packageName, boolean enable) {
        try {
            return enable ? LVMManagerServiceHolder.getService().enableModule(packageName) : LVMManagerServiceHolder.getService().disableModule(packageName);
        } catch (RemoteException e) {
            Log.e(TAG, Log.getStackTraceString(e));
            return false;
        }
    }

    public static boolean setModuleScope(String packageName, Set<ApplicationWithEquals> applications) {
        try {
            List<Application> list = new ArrayList<>();
            for (ApplicationWithEquals application : applications) {
                Application app = new Application();
                app.userId = application.userId;
                app.packageName = application.packageName;
                list.add(app);
            }
            return LVMManagerServiceHolder.getService().setModuleScope(packageName, list);
        } catch (RemoteException e) {
            Log.e(TAG, Log.getStackTraceString(e));
            return false;
        }
    }

    public static List<ApplicationWithEquals> getModuleScope(final String packageName) {
        List<ApplicationWithEquals> list = new ArrayList<>();
        try {
            List<Application> applications = LVMManagerServiceHolder.getService().getModuleScope(packageName);
            if (applications == null) {
                return list;
            }
            for (Application application : applications) {
                if (!application.packageName.equals(packageName)) {
                    list.add(new ApplicationWithEquals(application));
                }
            }
        } catch (RemoteException e) {
            Log.e(TAG, Log.getStackTraceString(e));
        }
        return list;
    }

    public static boolean enableStatusNotification() {
        try {
            return LVMManagerServiceHolder.getService().enableStatusNotification();
        } catch (RemoteException e) {
            Log.e(TAG, Log.getStackTraceString(e));
            return false;
        }
    }

    public static boolean setEnableStatusNotification(boolean enabled) {
        try {
            LVMManagerServiceHolder.getService().setEnableStatusNotification(enabled);
            return true;
        } catch (RemoteException e) {
            Log.e(TAG, Log.getStackTraceString(e));
            return false;
        }
    }

    public static boolean isVerboseLogEnabled() {
        try {
            return LVMManagerServiceHolder.getService().isVerboseLog();
        } catch (RemoteException e) {
            Log.e(TAG, Log.getStackTraceString(e));
            return false;
        }
    }

    public static boolean setVerboseLogEnabled(boolean enabled) {
        try {
            LVMManagerServiceHolder.getService().setVerboseLog(enabled);
            return true;
        } catch (RemoteException e) {
            Log.e(TAG, Log.getStackTraceString(e));
            return false;
        }
    }

    public static ParcelFileDescriptor getLog(boolean verbose) {
        try {
            return verbose ? LVMManagerServiceHolder.getService().getVerboseLog() : LVMManagerServiceHolder.getService().getModulesLog();
        } catch (RemoteException e) {
            Log.e(TAG, Log.getStackTraceString(e));
            return null;
        }
    }

    public static boolean clearLogs(boolean verbose) {
        try {
            return LVMManagerServiceHolder.getService().clearLogs(verbose);
        } catch (RemoteException e) {
            Log.e(TAG, Log.getStackTraceString(e));
            return false;
        }
    }

    public static PackageInfo getPackageInfo(String packageName, int flags, int userId) throws PackageManager.NameNotFoundException {
        try {
            PackageInfo info = LVMManagerServiceHolder.getService().getPackageInfo(packageName, flags, userId);
            if (info == null) throw new PackageManager.NameNotFoundException();
            return info;
        } catch (RemoteException e) {
            Log.e(TAG, Log.getStackTraceString(e));
            throw new PackageManager.NameNotFoundException();
        }
    }

    public static boolean forceStopPackage(String packageName, int userId) {
        try {
            LVMManagerServiceHolder.getService().forceStopPackage(packageName, userId);
            return true;
        } catch (RemoteException e) {
            Log.e(TAG, Log.getStackTraceString(e));
            return false;
        }
    }

    public static boolean reboot(boolean shutdown) {
        try {
            LVMManagerServiceHolder.getService().reboot(shutdown);
            return true;
        } catch (RemoteException e) {
            Log.e(TAG, Log.getStackTraceString(e));
            return false;
        }
    }

    public static boolean uninstallPackage(String packageName, int userId) {
        try {
            return LVMManagerServiceHolder.getService().uninstallPackage(packageName, userId);
        } catch (RemoteException e) {
            Log.e(TAG, Log.getStackTraceString(e));
            return false;
        }
    }

    public static boolean isSepolicyLoaded() {
        try {
            return LVMManagerServiceHolder.getService().isSepolicyLoaded();
        } catch (RemoteException e) {
            Log.e(TAG, Log.getStackTraceString(e));
            return false;
        }
    }

    public static List<UserInfo> getUsers() {
        try {
            return LVMManagerServiceHolder.getService().getUsers();
        } catch (RemoteException e) {
            Log.e(TAG, Log.getStackTraceString(e));
            return null;
        }
    }

    public static boolean installExistingPackageAsUser(String packageName, int userId) {
        final int INSTALL_SUCCEEDED = 1;
        try {
            int ret = LVMManagerServiceHolder.getService().installExistingPackageAsUser(packageName, userId);
            return ret == INSTALL_SUCCEEDED;
        } catch (RemoteException e) {
            Log.e(TAG, Log.getStackTraceString(e));
            return false;
        }
    }

    public static boolean isMagiskInstalled() {
        String path = System.getenv("PATH");
        if (path == null) {
            return false;
        } else {
            String[] ps = path.split(File.pathSeparator);
            for (String str : ps) {
                if (new File(str, "magisk").exists()) {
                    return true;
                }
            }
        }
        return false;
    }

    public static boolean systemServerRequested() {
        try {
            return LVMManagerServiceHolder.getService().systemServerRequested();
        } catch (RemoteException e) {
            return false;
        }
    }

    public static boolean dex2oatFlagsLoaded() {
        try {
            return LVMManagerServiceHolder.getService().dex2oatFlagsLoaded();
        } catch (RemoteException e) {
            return false;
        }
    }

    public static int startActivityAsUserWithFeature(Intent intent, int userId) {
        try {
            return LVMManagerServiceHolder.getService().startActivityAsUserWithFeature(intent, userId);
        } catch (RemoteException e) {
            Log.e(TAG, Log.getStackTraceString(e));
            return -1;
        }
    }

    public static List<ResolveInfo> queryIntentActivitiesAsUser(Intent intent, int flags, int userId) {
        List<ResolveInfo> list = new ArrayList<>();
        try {
            list.addAll(LVMManagerServiceHolder.getService().queryIntentActivitiesAsUser(intent, flags, userId).getList());
        } catch (RemoteException e) {
            Log.e(TAG, Log.getStackTraceString(e));
        }
        return list;
    }

    public static boolean setHiddenIcon(boolean hide) {
        try {
            LVMManagerServiceHolder.getService().setHiddenIcon(hide);
            return true;
        } catch (RemoteException e) {
            Log.e(TAG, Log.getStackTraceString(e));
            return false;
        }
    }

    public static String getApi() {
        try {
            return LVMManagerServiceHolder.getService().getApi();
        } catch (RemoteException e) {
            Log.e(TAG, Log.getStackTraceString(e));
            return e.toString();
        }
    }

    public static List<String> getDenyListPackages() {
        List<String> list = new ArrayList<>();
        try {
            list.addAll(LVMManagerServiceHolder.getService().getDenyListPackages());
        } catch (RemoteException e) {
            Log.e(TAG, Log.getStackTraceString(e));
        }
        return list;
    }

    public static void flashZip(String zipPath, ParcelFileDescriptor outputStream) {
        try {
            LVMManagerServiceHolder.getService().flashZip(zipPath, outputStream);
        } catch (RemoteException e) {
            Log.e(TAG, Log.getStackTraceString(e));
        }
    }

    public static boolean isDexObfuscateEnabled() {
        try {
            return LVMManagerServiceHolder.getService().getDexObfuscate();
        } catch (RemoteException e) {
            Log.e(TAG, Log.getStackTraceString(e));
            return false;
        }
    }

    public static boolean setDexObfuscateEnabled(boolean enabled) {
        try {
            LVMManagerServiceHolder.getService().setDexObfuscate(enabled);
            return true;
        } catch (RemoteException e) {
            Log.e(TAG, Log.getStackTraceString(e));
            return false;
        }
    }

    public static int getDex2OatWrapperCompatibility() {
        try {
            return LVMManagerServiceHolder.getService().getDex2OatWrapperCompatibility();
        } catch (RemoteException e) {
            Log.e(TAG, Log.getStackTraceString(e));
            return ILVMManagerService.DEX2OAT_CRASHED;
        }
    }

    public static class ApplicationWithEquals extends Application {
        public ApplicationWithEquals(String packageName, int userId) {
            this.packageName = packageName;
            this.userId = userId;
        }

        public ApplicationWithEquals(Application application) {
            packageName = application.packageName;
            userId = application.userId;
        }

        @Override
        public boolean equals(@Nullable Object obj) {
            if (!(obj instanceof Application)) {
                return false;
            }
            return packageName.equals(((Application) obj).packageName) && userId == ((Application) obj).userId;
        }

        @Override
        public int hashCode() {
            return Objects.hash(packageName, userId);
        }
    }
}
