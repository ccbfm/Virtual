package com.poetry.common.model.command;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class LogModel implements Serializable {

    @SerializedName("tag")
    public String tag;

    @SerializedName("level")
    public int level;

    @SerializedName("msg")
    public String msg;

    public LogModel(String tag, int level, String msg) {
        this.tag = tag;
        this.level = level;
        this.msg = msg;
    }
}
