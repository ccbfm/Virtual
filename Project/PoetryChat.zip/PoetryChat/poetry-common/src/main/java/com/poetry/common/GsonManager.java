package com.poetry.common;

import com.google.gson.Gson;

import java.lang.reflect.Type;

public class GsonManager {

    private final Gson mGson;

    private GsonManager() {
        mGson = new Gson();
    }

    private static final class Singleton {
        private static final GsonManager INSTANCE = new GsonManager();
    }

    public static GsonManager instance() {
        return GsonManager.Singleton.INSTANCE;
    }


    /**
     * 将json转化为对应的实体对象
     * new TypeToken<HashMap<String, Object>>(){}.getType()
     */
    public <T> T fromJson(String json, Type type) {
        return mGson.fromJson(json, type);
    }

    /**
     * 将json字符串转化成实体对象
     *
     * @param json json字符串
     * @param <T>  目标对象类型
     * @return 目标对象实例
     */
    public <T> T fromJson(String json, Class<T> clz) {
        return mGson.fromJson(json, clz);
    }

    /**
     * toJson
     *
     * @param obj 对象
     * @return String
     */
    public String toJson(Object obj) {
        return mGson.toJson(obj);
    }


}
