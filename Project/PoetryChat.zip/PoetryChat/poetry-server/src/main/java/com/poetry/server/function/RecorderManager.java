package com.poetry.server.function;

import android.content.Context;
import android.media.MediaRecorder;
import android.os.Build;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyCallback;
import android.telephony.TelephonyManager;
import android.util.Log;

import androidx.annotation.RequiresApi;

import java.io.File;
import java.text.MessageFormat;
import java.util.Date;
import java.util.concurrent.Executors;

public class RecorderManager {

    private RecorderManager() {
    }

    private static final class Singleton {
        private static final RecorderManager INSTANCE = new RecorderManager();
    }

    public static RecorderManager instance() {
        return RecorderManager.Singleton.INSTANCE;
    }

    private static final String TAG = "RecorderManager";

    private String mRootPath;
    private MediaRecorder mRecorder;

    public void init(Context context) {
        mRootPath = context.getExternalCacheDir() + "/RecorderVideo/";
        File rootFile = new File(mRootPath);
        if (!rootFile.exists()) {
            Log.i(TAG, "rootFile mkdirs: " + rootFile.mkdirs());
        }
    }

    public void listenTelephony(Context context) {
        TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        // 监听电话状态
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            tm.registerTelephonyCallback(Executors.newSingleThreadExecutor(), new StateCallback());
        } else {
            tm.listen(new StateListener(), PhoneStateListener.LISTEN_CALL_STATE);
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.S)
    private class StateCallback extends TelephonyCallback implements TelephonyCallback.CallStateListener {

        @Override
        public void onCallStateChanged(int state) {
            Log.i(TAG, "onCallStateChanged state " + state);
            switch (state) {
                case TelephonyManager.CALL_STATE_IDLE:
                    //Log.i(TAG, "手机状态：空闲状态");
                    stopRecord();
                    break;
                case TelephonyManager.CALL_STATE_RINGING:
                    //Log.i(TAG, "手机状态：来电话状态");
                    break;
                case TelephonyManager.CALL_STATE_OFFHOOK:
                    //Log.i(TAG, "手机状态：接电话状态");
                    startRecord();
                    break;
            }
        }
    }

    private class StateListener extends PhoneStateListener {
        public StateListener() {

        }

        @Override
        public void onCallStateChanged(int state, String phoneNumber) {
            super.onCallStateChanged(state, phoneNumber);
            Log.i(TAG, "onCallStateChanged state " + state + " " + phoneNumber);
            switch (state) {
                case TelephonyManager.CALL_STATE_IDLE:
                    //Log.i(TAG, "手机状态：空闲状态");
                    stopRecord();
                    break;
                case TelephonyManager.CALL_STATE_RINGING:
                    //Log.i(TAG, "手机状态：来电话状态");
                    String outputPath = initRecord(phoneNumber);
                    break;
                case TelephonyManager.CALL_STATE_OFFHOOK:
                    //Log.i(TAG, "手机状态：接电话状态");
                    startRecord();
                    break;
            }
        }
    }

    private String initRecord(String incomingNumber) {
        String createTime = MessageFormat.format("{0,date,yyyy_MM_dd_HH_mm_ss}",
                new Date(System.currentTimeMillis()));
        mRecorder = new MediaRecorder();
        mRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        mRecorder.setOutputFormat(MediaRecorder.OutputFormat.AMR_NB);
        mRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
        String outputPath = mRootPath + incomingNumber + "_" + createTime + ".amr";
        mRecorder.setOutputFile(outputPath);
        try {
            mRecorder.prepare();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return outputPath;
    }

    private void startRecord() {
        if (mRecorder != null) {
            mRecorder.start();
        }
    }

    private void stopRecord() {
        if (mRecorder != null) {
            mRecorder.stop();
            mRecorder.release();
            mRecorder = null;
        }
    }
}
