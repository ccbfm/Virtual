package com.poetry.server;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Build;
import android.telephony.TelephonyManager;
import android.text.TextUtils;

import com.virtual.util.log.VLog;

public class PoetryDataManager {

    private static final String TAG = "PoetryDataManager";

    private PoetryDataManager() {
    }

    private static final class Singleton {
        private static final PoetryDataManager INSTANCE = new PoetryDataManager();
    }

    public static PoetryDataManager instance() {
        return PoetryDataManager.Singleton.INSTANCE;
    }


    public void init(Context context) {
        initDeviceId(context);
    }

    private String mDeviceId = "";

    @SuppressLint("HardwareIds")
    private void initDeviceId(Context context) {
        if (TextUtils.isEmpty(mDeviceId)) {
            TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                mDeviceId = telephonyManager.getImei();
            } else {
                mDeviceId = telephonyManager.getDeviceId();
            }
            VLog.w(TAG, "initDeviceId " + mDeviceId);
        }
    }

}
