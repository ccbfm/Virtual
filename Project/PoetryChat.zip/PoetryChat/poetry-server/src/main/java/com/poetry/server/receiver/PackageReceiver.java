package com.poetry.server.receiver;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Handler;

import androidx.annotation.NonNull;

import com.virtual.util.log.VLog;

public class PackageReceiver extends BroadcastReceiver {
    private static final String TAG = "InstallReceiver";
    private final String mPackageName, mClassName;

    public PackageReceiver(@NonNull String packageName, @NonNull String className) {
        mPackageName = packageName;
        mClassName = className;
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        final String action = intent.getAction();
        VLog.d(TAG, "onReceive action " + action + " " + intent.getDataString());
        if (Intent.ACTION_PACKAGE_REPLACED.equals(action)) {
            Uri data = intent.getData();
            if (data == null) return;
            String packageName = intent.getData().getSchemeSpecificPart();
            if (mPackageName.equals(packageName)) {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Intent intent_start = new Intent();
                            intent_start.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            intent_start.setComponent(new ComponentName(mPackageName, mClassName));
                            context.startActivity(intent_start);
                            VLog.d(TAG, "onReceive startActivity ");
                        } catch (Throwable throwable) {
                            VLog.e(TAG, "onReceive startActivity Throwable ", throwable);
                        }
                    }
                }, 3000);
            }
        }
    }

    public static void registerInstallReceiver(Context context, @NonNull String packageName, @NonNull String className) {
        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_PACKAGE_ADDED);
        filter.addAction(Intent.ACTION_PACKAGE_CHANGED);
        filter.addAction(Intent.ACTION_PACKAGE_REMOVED);
        filter.addAction(Intent.ACTION_PACKAGE_REPLACED);
        filter.addDataScheme("package");
        context.registerReceiver(new PackageReceiver(packageName, className), filter);
    }
}
