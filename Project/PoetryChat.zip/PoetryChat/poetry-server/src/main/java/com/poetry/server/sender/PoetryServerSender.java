package com.poetry.server.sender;

public final class PoetryServerSender {

    
}
