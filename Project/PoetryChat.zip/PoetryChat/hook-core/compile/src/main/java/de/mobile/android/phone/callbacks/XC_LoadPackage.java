package de.mobile.android.phone.callbacks;

public class XC_LoadPackage {
}
