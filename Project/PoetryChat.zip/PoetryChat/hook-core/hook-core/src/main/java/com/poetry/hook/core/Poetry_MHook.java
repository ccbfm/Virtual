package com.poetry.hook.core;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.lang.reflect.Executable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Member;
import java.util.ConcurrentModificationException;
import java.util.HashMap;

import de.mobile.android.phone.XC_MethodHook;

public abstract class Poetry_MHook {
    public final int priority;

    public Poetry_MHook() {
        this.priority = 50;
    }

    public Poetry_MHook(int priority) {
        this.priority = priority;
    }

    protected void beforeHookedMethod(MHookParam param) throws Throwable {

    }

    public void callBeforeHookedMethod(MHookParam param) throws Throwable {
        this.beforeHookedMethod(param);
    }

    protected void afterHookedMethod(MHookParam param) throws Throwable {
    }

    public void callAfterHookedMethod(MHookParam param) throws Throwable {
        this.afterHookedMethod(param);
    }

    public static final class MHookParam<T extends Executable> {
        public Member method;
        public Object thisObject;
        public Object[] args;
        private Object result = null;
        private Throwable throwable = null;
        public boolean returnEarly = false;
        private final HashMap<String, Object> extras = new HashMap<>();
        private final XC_MethodHook.MethodHookParam<T> methodHookParam;

        public MHookParam(XC_MethodHook.MethodHookParam<T> methodHookParam) {
            this.methodHookParam = methodHookParam;
            this.method = methodHookParam.method;
            this.thisObject = methodHookParam.thisObject;
            this.args = methodHookParam.args;
            this.returnEarly = methodHookParam.returnEarly;

        }

        public Object getResult() {
            return this.methodHookParam.getResult();
        }

        public void setResult(Object result) {
            this.methodHookParam.setResult(result);
            this.returnEarly = true;
        }

        public Throwable getThrowable() {
            return this.methodHookParam.getThrowable();
        }

        public boolean isSkipped() {
            return this.methodHookParam.isSkipped();
        }

        public boolean hasThrowable() {
            return this.methodHookParam.hasThrowable();
        }

        public void setThrowable(Throwable throwable) {
            this.methodHookParam.setThrowable(throwable);
        }

        public Object getResultOrThrowable() throws Throwable {
            return this.methodHookParam.getResultOrThrowable();
        }

        @NonNull
        public T getOrigin() {
            return this.methodHookParam.getOrigin();
        }

        @Nullable
        public Object getThis() {
            return this.methodHookParam.getThis();
        }

        @NonNull
        public Object[] getArgs() {
            return this.methodHookParam.getArgs();
        }

        @Nullable
        public <U> U getArg(int index) {
            return this.methodHookParam.getArg(index);
        }

        public <U> void setArg(int index, U value) {
            this.methodHookParam.setArg(index, value);
        }

        public void returnAndSkip(@Nullable Object returnValue) {
            this.methodHookParam.returnAndSkip(returnValue);
        }

        public void throwAndSkip(@Nullable Throwable throwable) {
            this.methodHookParam.throwAndSkip(throwable);
        }

        @Nullable
        public Object invokeOrigin() throws InvocationTargetException, IllegalAccessException {
            return this.methodHookParam.invokeOrigin();
        }

        @Nullable
        public <U> U getExtra(@NonNull String key) {
            return this.methodHookParam.getExtra(key);
        }

        public <U> void setExtra(@NonNull String key, @Nullable U value) throws ConcurrentModificationException {
            this.methodHookParam.setExtra(key, value);
        }
    }


    public static class UnHook {
        private final XC_MethodHook.Unhook unhook;

        UnHook(XC_MethodHook.Unhook unhook) {
            this.unhook = unhook;
        }

        public Member getHookedMethod() {
            return this.unhook.getHookedMethod();
        }

        public XC_MethodHook getCallback() {
            return this.unhook.getCallback();
        }

        public void unhook() {
            this.unhook.unhook();
        }
    }
}
