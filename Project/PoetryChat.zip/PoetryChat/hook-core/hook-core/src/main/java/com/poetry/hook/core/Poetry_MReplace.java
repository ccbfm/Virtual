package com.poetry.hook.core;

public abstract class Poetry_MReplace extends Poetry_MHook {

    public Poetry_MReplace() {
    }

    public Poetry_MReplace(int priority) {
        super(priority);
    }

    protected abstract Object replaceHookedMethod(Poetry_MHook.MHookParam var1) throws Throwable;

}
