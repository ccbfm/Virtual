package com.poetry.hook.core;

import android.content.pm.ApplicationInfo;

import de.mobile.android.phone.callbacks.XC_LoadPackage;

public abstract class PLoadPackage extends XC_LoadPackage {

    @Override
    public void handleLoadPackage(LoadPackageParam loadPackageParam) throws Throwable {
        handleLoadPackage(new PPackageParam(loadPackageParam));
    }

    public abstract void handleLoadPackage(PPackageParam param);

    public static final class PPackageParam {
        public String packageName;
        public String processName;
        public ClassLoader classLoader;
        public ApplicationInfo appInfo;
        public boolean isFirstApplication;

        public PPackageParam(LoadPackageParam loadPackageParam) {
            this.packageName = loadPackageParam.packageName;
            this.processName = loadPackageParam.processName;
            this.classLoader = loadPackageParam.classLoader;
            this.appInfo = loadPackageParam.appInfo;
            this.isFirstApplication = loadPackageParam.isFirstApplication;
        }
    }
}
