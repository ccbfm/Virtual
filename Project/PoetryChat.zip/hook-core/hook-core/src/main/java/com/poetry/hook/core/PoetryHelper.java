package com.poetry.hook.core;

import androidx.annotation.NonNull;

import java.util.HashSet;
import java.util.Set;

import de.mobile.android.phone.MobileBridge;
import de.mobile.android.phone.MobileHelpers;
import de.mobile.android.phone.XC_MethodHook;
import de.mobile.android.phone.XC_MethodReplacement;

public final class PoetryHelper {

    private static class XC_MethodReplacement extends de.mobile.android.phone.XC_MethodReplacement {
        Poetry_MReplace callback;

        public XC_MethodReplacement(Poetry_MReplace callback) {
            super(callback.priority);
            this.callback = callback;
        }

        @Override
        protected Object replaceHookedMethod(MethodHookParam methodHookParam) throws Throwable {
            return callback.replaceHookedMethod(new Poetry_MHook.MHookParam(methodHookParam));
        }
    }

    private static class XC_MethodHook extends de.mobile.android.phone.XC_MethodHook {
        Poetry_MHook callback;

        public XC_MethodHook(Poetry_MHook callback) {
            super(callback.priority);
            this.callback = callback;
        }

        @Override
        protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
            callback.beforeHookedMethod(new Poetry_MHook.MHookParam(param));
        }

        @Override
        public void callBeforeHookedMethod(MethodHookParam param) throws Throwable {
            callback.callBeforeHookedMethod(new Poetry_MHook.MHookParam(param));
        }

        @Override
        protected void afterHookedMethod(MethodHookParam param) throws Throwable {
            callback.afterHookedMethod(new Poetry_MHook.MHookParam(param));
        }

        @Override
        public void callAfterHookedMethod(MethodHookParam param) throws Throwable {
            callback.callAfterHookedMethod(new Poetry_MHook.MHookParam(param));
        }
    }
    private static de.mobile.android.phone.XC_MethodHook createXC_MethodHook(Poetry_MHook callback) {
        if (callback instanceof Poetry_MReplace) {
            Poetry_MReplace replace = (Poetry_MReplace) callback;
            return new XC_MethodReplacement(replace);
        } else {
            return new XC_MethodHook(callback);
        }
    }

    public static Class<?> findClass(String className, ClassLoader classLoader) {
        return MobileHelpers.findClass(className, classLoader);
    }

    public static Poetry_MHook.UnHook findAndHookMethodR(Class<?> clazz, String methodName, Poetry_MHook callback) {
        return findAndHookMethodR(clazz, methodName, new Class[0], callback);
    }

    public static Poetry_MHook.UnHook findAndHookMethodR(Class<?> clazz, String methodName, @NonNull Class<?>[] parameterTypes, Poetry_MHook callback) {
        java.lang.reflect.Method m = MobileHelpers.findMethodExact(clazz, methodName, parameterTypes);
        XC_MethodHook.Unhook unhook = MobileBridge.hookMethod(m, createXC_MethodHook(callback));
        return new Poetry_MHook.UnHook(unhook);
    }

    public static void findAndHookMethod(Class<?> clazz, String methodName, Poetry_MHook callback) {
        findAndHookMethod(clazz, methodName, new Class[0], callback);
    }

    public static void findAndHookMethod(Class<?> clazz, String methodName, @NonNull Class<?>[] parameterTypes, Poetry_MHook callback) {
        java.lang.reflect.Method m = MobileHelpers.findMethodExact(clazz, methodName, parameterTypes);
        MobileBridge.hookMethod(m, createXC_MethodHook(callback));
    }

    public static Set<Poetry_MHook.UnHook> hookAllMethodsR(Class<?> clazz, String methodName, Poetry_MHook callback) {
        Set<XC_MethodHook.Unhook> unhooks = MobileBridge.hookAllMethods(clazz, methodName, createXC_MethodHook(callback));

        Set<Poetry_MHook.UnHook> results = new HashSet<>();
        for (XC_MethodHook.Unhook unhook : unhooks) {
            results.add(new Poetry_MHook.UnHook(unhook));
        }
        return results;
    }


    public static void hookAllMethods(Class<?> clazz, String methodName, Poetry_MHook callback) {
        MobileBridge.hookAllMethods(clazz, methodName, createXC_MethodHook(callback));
    }

    public static Poetry_MHook.UnHook findAndHookConstructorR(Class<?> clazz, @NonNull Class<?>[] parameterTypes, Poetry_MHook callback) {
        java.lang.reflect.Constructor<?> m = MobileHelpers.findConstructorExact(clazz, parameterTypes);
        XC_MethodHook.Unhook unhook = MobileBridge.hookMethod(m, createXC_MethodHook(callback));
        return new Poetry_MHook.UnHook(unhook);
    }

    public static Poetry_MHook.UnHook findAndHookConstructorR(Class<?> clazz, Poetry_MHook callback) {
        return findAndHookConstructorR(clazz, new Class[0], callback);
    }

    public static void findAndHookConstructor(Class<?> clazz, @NonNull Class<?>[] parameterTypes, Poetry_MHook callback) {
        java.lang.reflect.Constructor<?> m = MobileHelpers.findConstructorExact(clazz, parameterTypes);
        MobileBridge.hookMethod(m, createXC_MethodHook(callback));
    }

    public static void findAndHookConstructor(Class<?> clazz, Poetry_MHook callback) {
        findAndHookConstructor(clazz, new Class[0], callback);
    }

    public static Set<Poetry_MHook.UnHook> hookAllConstructorsR(Class<?> clazz, Poetry_MHook callback) {
        Set<XC_MethodHook.Unhook> unhooks = MobileBridge.hookAllConstructors(clazz, createXC_MethodHook(callback));

        Set<Poetry_MHook.UnHook> results = new HashSet<>();
        for (XC_MethodHook.Unhook unhook : unhooks) {
            results.add(new Poetry_MHook.UnHook(unhook));
        }
        return results;
    }

    public static void hookAllConstructors(Class<?> clazz, Poetry_MHook callback) {
        MobileBridge.hookAllConstructors(clazz, createXC_MethodHook(callback));
    }


    public static void setObjectField(Object obj, String fieldName, Object value) {
        MobileHelpers.setObjectField(obj, fieldName, value);
    }

    public static void setBooleanField(Object obj, String fieldName, boolean value) {
        MobileHelpers.setBooleanField(obj, fieldName, value);
    }

    public static void setByteField(Object obj, String fieldName, byte value) {
        MobileHelpers.setByteField(obj, fieldName, value);
    }

    public static void setCharField(Object obj, String fieldName, char value) {
        MobileHelpers.setCharField(obj, fieldName, value);
    }

    public static void setDoubleField(Object obj, String fieldName, double value) {
        MobileHelpers.setDoubleField(obj, fieldName, value);
    }

    public static void setFloatField(Object obj, String fieldName, float value) {
        MobileHelpers.setFloatField(obj, fieldName, value);
    }

    public static void setIntField(Object obj, String fieldName, int value) {
        MobileHelpers.setIntField(obj, fieldName, value);
    }

    public static void setLongField(Object obj, String fieldName, long value) {
        MobileHelpers.setLongField(obj, fieldName, value);
    }

    public static void setShortField(Object obj, String fieldName, short value) {
        MobileHelpers.setShortField(obj, fieldName, value);
    }

    public static Object getObjectField(Object obj, String fieldName) {
        return MobileHelpers.getObjectField(obj, fieldName);
    }

    public static Object getSurroundingThis(Object obj) {
        return getObjectField(obj, "this$0");
    }

    public static boolean getBooleanField(Object obj, String fieldName) {
        return MobileHelpers.getBooleanField(obj, fieldName);
    }

    public static byte getByteField(Object obj, String fieldName) {
        return MobileHelpers.getByteField(obj, fieldName);
    }

    public static char getCharField(Object obj, String fieldName) {
        return MobileHelpers.getCharField(obj, fieldName);
    }

    public static double getDoubleField(Object obj, String fieldName) {
        return MobileHelpers.getDoubleField(obj, fieldName);
    }

    public static float getFloatField(Object obj, String fieldName) {
        return MobileHelpers.getFloatField(obj, fieldName);
    }

    public static int getIntField(Object obj, String fieldName) {
        return MobileHelpers.getIntField(obj, fieldName);
    }

    public static long getLongField(Object obj, String fieldName) {
        return MobileHelpers.getLongField(obj, fieldName);
    }

    public static short getShortField(Object obj, String fieldName) {
        return MobileHelpers.getShortField(obj, fieldName);
    }

    public static void setStaticObjectField(Class<?> clazz, String fieldName, Object value) {
        MobileHelpers.setStaticObjectField(clazz, fieldName, value);
    }

    public static void setStaticBooleanField(Class<?> clazz, String fieldName, boolean value) {
        MobileHelpers.setStaticBooleanField(clazz, fieldName, value);
    }

    public static void setStaticByteField(Class<?> clazz, String fieldName, byte value) {
        MobileHelpers.setStaticByteField(clazz, fieldName, value);
    }

    public static void setStaticCharField(Class<?> clazz, String fieldName, char value) {
        MobileHelpers.setStaticCharField(clazz, fieldName, value);
    }

    public static void setStaticDoubleField(Class<?> clazz, String fieldName, double value) {
        MobileHelpers.setStaticDoubleField(clazz, fieldName, value);
    }

    public static void setStaticFloatField(Class<?> clazz, String fieldName, float value) {
        MobileHelpers.setStaticFloatField(clazz, fieldName, value);
    }

    public static void setStaticIntField(Class<?> clazz, String fieldName, int value) {
        MobileHelpers.setStaticIntField(clazz, fieldName, value);
    }

    public static void setStaticLongField(Class<?> clazz, String fieldName, long value) {
        MobileHelpers.setStaticLongField(clazz, fieldName, value);
    }

    public static void setStaticShortField(Class<?> clazz, String fieldName, short value) {
        MobileHelpers.setStaticShortField(clazz, fieldName, value);
    }

    public static Object getStaticObjectField(Class<?> clazz, String fieldName) {
        return MobileHelpers.getStaticObjectField(clazz, fieldName);
    }

    public static boolean getStaticBooleanField(Class<?> clazz, String fieldName) {
        return MobileHelpers.getStaticBooleanField(clazz, fieldName);
    }

    public static byte getStaticByteField(Class<?> clazz, String fieldName) {
        return MobileHelpers.getStaticByteField(clazz, fieldName);
    }

    public static char getStaticCharField(Class<?> clazz, String fieldName) {
        return MobileHelpers.getStaticCharField(clazz, fieldName);
    }

    public static double getStaticDoubleField(Class<?> clazz, String fieldName) {
        return MobileHelpers.getStaticDoubleField(clazz, fieldName);
    }

    public static float getStaticFloatField(Class<?> clazz, String fieldName) {
        return MobileHelpers.getStaticFloatField(clazz, fieldName);
    }

    public static int getStaticIntField(Class<?> clazz, String fieldName) {
        return MobileHelpers.getStaticIntField(clazz, fieldName);
    }

    public static long getStaticLongField(Class<?> clazz, String fieldName) {
        return MobileHelpers.getStaticLongField(clazz, fieldName);
    }

    public static short getStaticShortField(Class<?> clazz, String fieldName) {
        return MobileHelpers.getStaticShortField(clazz, fieldName);
    }

    public static Object callMethod(Object obj, String methodName, Object... args) {
        return MobileHelpers.callMethod(obj, methodName, args);
    }

    public static Object callMethod(Object obj, String methodName, Class<?>[] parameterTypes, Object... args) {
        return MobileHelpers.callMethod(obj, methodName, parameterTypes, args);
    }

    public static Object callStaticMethod(Class<?> clazz, String methodName, Object... args) {
        return MobileHelpers.callStaticMethod(clazz, methodName, args);
    }

    public static Object callStaticMethod(Class<?> clazz, String methodName, Class<?>[] parameterTypes, Object... args) {
        return MobileHelpers.callStaticMethod(clazz, methodName, parameterTypes, args);
    }

    public static Object newInstance(Class<?> clazz, Object... args) {
        return MobileHelpers.newInstance(clazz, args);
    }

    public static Object newInstance(Class<?> clazz, Class<?>[] parameterTypes, Object... args) {
        return MobileHelpers.newInstance(clazz, parameterTypes, args);
    }
}
