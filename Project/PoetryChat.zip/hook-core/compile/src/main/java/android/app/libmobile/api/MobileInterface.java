package android.app.libmobile.api;

public interface MobileInterface {

    interface BeforeHookCallback {

    }

    interface AfterHookCallback {

    }
}
