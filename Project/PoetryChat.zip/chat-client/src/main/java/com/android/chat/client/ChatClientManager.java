package com.android.chat.client;

import android.content.Context;
import android.provider.Settings;
import android.util.Log;

import com.poetry.common.SettingConfig;
import com.poetry.common.SocketCommon;
import com.virtual.util.log.VLog;
import com.virtual.util.log.VLogConfig;
import com.virtual.util.socket.net.VNetSocket;

import java.net.Socket;


public class ChatClientManager {
    private static final String TAG = "ChatClientManager";

    private ChatClientManager() {
    }

    private static final class Singleton {
        private static final ChatClientManager INSTANCE = new ChatClientManager();
    }

    public static ChatClientManager instance() {
        return Singleton.INSTANCE;
    }


    private volatile boolean mInit = false;

    public synchronized void start(final Context context) {
        if (context == null) {
            Log.w(TAG, "start context is null.");
            return;
        }
        if (context.getExternalFilesDir(null) == null) {
            Log.d(TAG, "start externalFiles is null.");
            return;
        }
        if (mInit) {
            //VLog.d(TAG, "start init.");
            return;
        }
        mInit = true;
        VLogConfig.instance().defaultConfig(context, "ChatClient", SettingConfig.DEBUG);
        try {
            new Thread("chat_client_init") {
                @Override
                public void run() {
                    try {

                    } catch (Throwable throwable) {
                        VLog.e(TAG, "init Throwable ", throwable);
                    }
                }
            }.start();
            new Thread("chat_client_start") {
                @Override
                public void run() {
                    initNetClientServer(context);
                }
            }.start();
        } catch (Throwable throwable) {
            VLog.e(TAG, "start Throwable ", throwable);
            mInit = false;
        }
    }

    private final Object mLockClient = new Object();

    private void initNetClientServer(Context context) {
        try {
            VLog.w(TAG, "initNetClientServer start.");
            synchronized (mLockClient) {
                final int[] success = {0, 0};
                while (true) {
                    int serverPort = Settings.Global.getInt(context.getContentResolver(), SocketCommon.NAME_SOCKET_SERVER_PORT, 0);
                    VLog.w(TAG, "initNetClientServer start serverPort " + serverPort);
                    if (serverPort == 0) {
                        mLockClient.wait(5000);
                        continue;
                    }
                    VNetSocket.startClient(new ChatClient(serverPort) {
                        @Override
                        protected void linkSuccess(Socket socket) {
                            super.linkSuccess(socket);
                            int localPort = socket.getLocalPort();
                            success[0] = 1;
                            success[1] = localPort;
                            synchronized (mLockClient) {
                                mLockClient.notify();
                            }
                        }

                        @Override
                        protected void doThrowable() {
                            super.doThrowable();
                            synchronized (mLockClient) {
                                mLockClient.notify();
                            }
                        }
                    });
                    mLockClient.wait();
                    if (success[0] == 1) {
                        VLog.w(TAG, "initNetClientServer success. port:" + serverPort + " " + success[1]);
                        break;
                    } else {
                        VLog.w(TAG, "initNetClientServer fail.");
                    }
                }
            }
            VLog.w(TAG, "initNetClientServer end.");
        } catch (Throwable throwable) {
            VLog.e(TAG, "start run NetSocket startServer ", throwable);
        }
    }

}
