package com.android.chat.client.sender;

import androidx.annotation.NonNull;

import com.poetry.common.SocketCommon;
import com.poetry.common.model.CommandModel;
import com.poetry.common.model.command.LogModel;
import com.virtual.util.common.NonNullExecute;
import com.virtual.util.log.VLogLevel;
import com.virtual.util.socket.net.VNetSocket;
import com.virtual.util.socket.net.client.VClient;

public final class ChatClientSender {

    public static void sendLogD(String tag, String msg) {
        sendLog(tag, VLogLevel.D, msg);
    }

    public static void sendLogI(String tag, String msg) {
        sendLog(tag, VLogLevel.I, msg);
    }

    public static void sendLogW(String tag, String msg) {
        sendLog(tag, VLogLevel.W, msg);
    }

    public static void sendLogE(String tag, String msg) {
        sendLog(tag, VLogLevel.E, msg);
    }

    public static void sendLog(String tag, int level, String msg) {
        NonNullExecute.execute(getClient(), new NonNullExecute.IExecute<VClient>() {
            @Override
            public void execute(@NonNull VClient vClient) {
                vClient.send(CommandModel.toJson(SocketCommon.Command.LOG, new LogModel(tag, level, msg)));
            }
        });
    }

    private static VClient getClient() {
        return VNetSocket.getClient(SocketCommon.NAME_CHAT_CLIENT);
    }
}
