package com.android.chat.client;

import androidx.annotation.NonNull;

import com.poetry.common.SocketCommon;
import com.virtual.util.socket.net.client.VClient;

public class ChatClient extends VClient {
    private final int port;

    public ChatClient(int port) {
        this.port = port;
    }

    @Override
    protected int port() {
        return port;
    }

    @NonNull
    @Override
    public String name() {
        return SocketCommon.NAME_CHAT_CLIENT;
    }

    @Override
    protected void handleResult(String s) {

    }
}
